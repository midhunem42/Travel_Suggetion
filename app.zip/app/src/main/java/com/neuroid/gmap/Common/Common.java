package com.neuroid.gmap.Common;

import com.neuroid.gmap.Modules.PolylineData;
import com.neuroid.gmap.model.Review;

import java.util.ArrayList;
import java.util.List;

public class Common {
    public static ArrayList<PolylineData> polylineData = new ArrayList<>();
    public static String RID = "";
    public static  List<Review> reviewList  = new ArrayList<>();

}
