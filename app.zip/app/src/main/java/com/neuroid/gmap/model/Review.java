package com.neuroid.gmap.model;

public class Review {
    String feedBack;

    public Review(String feedBack) {
        this.feedBack = feedBack;
    }

    public String getFeedBack() {
        return feedBack;
    }

    public void setFeedBack(String feedBack) {
        this.feedBack = feedBack;
    }
}
